[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/yallau5/drivers/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>