

<?php $__env->startSection('main'); ?> 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Upcomming Trips</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Upcomming Trips</li>
                            </ol>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-md-12">
                            <div class="card card-box">
                                <div class="card-head">
                                    <header>Future Trips</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
	                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
	                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
                                    <div class="table-scrollable">
                                    <table id="tableExport" style="width: 100%">
								        <thead>
								            <tr>
								                <th>#</th>
								                <th>Trip Id</th>
								                <th>Passenger Name</th>
								                <th>Trip From</th>
								                <th>Trip To</th>
								                <th>Start Time</th>
								                <th>Action</th>
								            </tr>
								        </thead>
											<tbody>
												<tr>
													<td>1</td>
													<td>ID234</td>
													<td>John Smith</td>
													<td>34, Alax street</td>
													<td>99 Myrtle Dr.Long Branch</td>
													<td>22-03-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>2</td>
													<td>ID244</td>
													<td>William Miller</td>
													<td>823 Lincoln Ave.Huntsville</td>
													<td>3 Cedar Swamp Rd. Crown Point</td>
													<td>12-03-2018 12:40</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>3</td>
													<td>ID254</td>
													<td>Daniel Davis</td>
													<td>7578 Vale Ave. Canfield</td>
													<td>619 S. Wayne Ave. Fairport</td>
													<td>16-03-2018 11:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>4</td>
													<td>ID264</td>
													<td>Kevin Wilson</td>
													<td>568 Canal Street Toledo</td>
													<td>892 Myers Ave. Des Moines</td>
													<td>11-03-2018 02:14</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>5</td>
													<td>ID274</td>
													<td>Jason Smith</td>
													<td>114 East Edgewood St.</td>
													<td>7 Glen Ridge Street Fairmont</td>
													<td>23-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>6</td>
													<td>ID284</td>
													<td>Ronald Thomas</td>
													<td>624 Monroe St. Irmo</td>
													<td>8373 S. Santa Clara Drive Mc Lean</td>
													<td>12-03-2018 12:55</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>7</td>
													<td>ID294</td>
													<td>Ryan Allen</td>
													<td>37 La Sierra St. Mount Holly</td>
													<td>425 Sage Street Leesburg</td>
													<td>02-03-2018 07:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>8</td>
													<td>ID236</td>
													<td>Brandon Hill</td>
													<td>61 East Tallwood Ave. Cumming</td>
													<td>8490 Middle River Ave. Roslindale</td>
													<td>16-03-2018 10:38</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>9</td>
													<td>ID233</td>
													<td>William Miller</td>
													<td>4 Bedford Dr. Ashland</td>
													<td>17 Lyme Ave. Redford</td>
													<td>09-03-2018 12:54</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>10</td>
													<td>ID237</td>
													<td>John Smith</td>
													<td>941 Foster Street Shakopee</td>
													<td>24 Amerige Rd. Utica</td>
													<td>12-03-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>11</td>
													<td>ID238</td>
													<td>William Miller</td>
													<td>37 La Sierra St. Mount Holly</td>
													<td>425 Sage Street Leesburg</td>
													<td>18-02-2018 18:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>12</td>
													<td>ID239</td>
													<td>Daniel Davis</td>
													<td>624 Monroe St. Irmo</td>
													<td>8373 S. Santa Clara Drive Mc Lean</td>
													<td>12-03-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>13</td>
													<td>ID231</td>
													<td>Kevin Wilson</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>23-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>14</td>
													<td>ID232</td>
													<td>Jason Smith</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>24-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>15</td>
													<td>ID233</td>
													<td>Ronald Thomas</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>13-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>16</td>
													<td>ID234</td>
													<td>Ryan Allen</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>27-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>17</td>
													<td>ID235</td>
													<td>Brandon Hill</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>21-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
												<tr>
													<td>18</td>
													<td>ID236</td>
													<td>John Smith</td>
													<td>34, Alax street</td>
													<td>Au, xyz road</td>
													<td>18-02-2018 12:34</td>
													<td>
														<a href="edit_booking.html" class="btn btn-tbl-edit btn-xs">
															<i class="fa fa-pencil"></i>
														</a>
														<button class="btn btn-tbl-delete btn-xs">
															<i class="fa fa-trash-o "></i>
														</button>
													</td>
												</tr>
											</tbody>
										</table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.driver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yalla\Desktop\drivers\resources\views/driver/upcomming_trips.blade.php ENDPATH**/ ?>