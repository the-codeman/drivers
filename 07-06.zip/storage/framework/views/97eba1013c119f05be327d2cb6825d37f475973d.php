<?php echo e($slot); ?>

<?php /**PATH /home/yallau5/drivers/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>