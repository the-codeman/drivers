    <script src="../assets1/plugins/jquery/jquery.min.js" ></script>
    <script src="../assets1/plugins/popper/popper.min.js" ></script>
    <script src="../assets1/plugins/jquery-blockui/jquery.blockui.min.js" ></script>
	<script src="../assets1/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets1/plugins/bootstrap/js/bootstrap.min.js" ></script>
	<script src="../assets1/js/bootbox.js" ></script>
	<script src="../assets1/js/app.js" ></script>
    <script src="../assets1/js/layout.js" ></script>
	<script src="../assets1/js/theme-color.js" ></script>
    <script src="../assets1/plugins/datatables/jquery.dataTables.min.js" ></script>
 	<script src="../assets1/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
 	<script src="../assets1/links/buttons/1.5.1/js/dataTables.buttons.min.js" ></script>
 	<script src="../assets1/links/ajax/libs/jszip/3.1.3/jszip.min.js" ></script>
 	<script src="../assets1/links/ajax/libs/pdfmake/0.1.32/pdfmake.min.js" ></script>
 	<script src="../assets1/links/ajax/libs/pdfmake/0.1.32/vfs_fonts.js" ></script>
 	<script src="../assets1/links/buttons/1.5.1/js/buttons.html5.min.js" ></script>
 	<script src="../assets1/js/pages/table/table_data.js" ></script>
	<script src="../assets1/plugins/material/material.min.js"></script>
	<script src="../assets1/js/pages/ui/animations.js" ></script>
    <script src="../assets1/js/jquery-ui.min.js"></script>
    <script src="../assets1/plugins/dataTables/jquery.dataTables.js"></script>
    
    <script src="../assets1/plugins/sparkline/jquery.sparkline.min.js" ></script>
	<script src="../assets1/js/pages/sparkline/sparkline-data.js" ></script>
    <script src="../assets1/plugins/morris/morris.min.js" ></script>
    <script src="../assets1/plugins/morris/raphael-min.js" ></script>
    <script src="../assets1/js/pages/chart/morris/morris_home_driver_data.js" ></script>
    
    
    
    
    
    

    <div class="page-footer">
        <div class="page-footer-inner"> 2021 &copy; Yalla UK 
            <a href="" target="_top" class="makerCss">Yalla App</a>
        </div>
        <div class="scroll-to-top">
            <i class="material-icons">eject</i>
        </div>
    </div>